﻿namespace FSharpSilverlightMvvmTemplate.Model

type Expense =
    { ExpenseType : string
      ExpenseAmount : string}
